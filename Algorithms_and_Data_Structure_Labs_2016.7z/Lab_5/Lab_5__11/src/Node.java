public class Node
{
    public Node left, right;
    public String key;
    public int val;
    public int N;

    public Node(String k, int v)
    {
        key = k;
        val = v;
    }
}