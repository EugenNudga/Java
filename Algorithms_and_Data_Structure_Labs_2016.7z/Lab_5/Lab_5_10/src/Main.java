
import java.util.StringTokenizer;

public class Main {

    public static void main(String[] args)
    {
        //usually we would use ArrayList, but this way it's kinda harder to develop (though easier to use),
        //so here's the way without using ArrayList
        //it can be fixed later (with ArrayList), if necessary
        //interesting fact: Dictionary function seems to be able to do work faster than the code in lecture

        BST tree = new BST();

        String S = "it was the best of times";
        //String S = "The book begins with Robert Jordan surveying an area of mountain terrain behind fascist lines. He's a young (or youngish) American volunteer fighting for the Republicans in the Spanish Civil War. (The Republicans are the good guys, fighting for freedom, democracy, and the common people.) A flashback informs us he's been ordered to blow up a nearby bridge in three days' time as part of a surprise attack on fascist forces there. (The fascists are the bad guys, who prefer military dictators and wealthy landowners to the common people.) The Fascists must not be allowed to get reinforcements over the bridge, and so Robert Jordan (with two big packs of explosives) has been tasked with destroying it. But he'll need to recruit some men to help him out, as there are two manned sentry posts on either side of the bridge.His guide in the area is Anselmo, who introduces him to Pablo, a grizzled guerrilla leader who's basically the boss in these parts. Pablo's not that eager to help Robert Jordan in his bridge-blowing extravaganza, and doesn't seem quite trustworthy. But eventually agrees, and leads Robert Jordan back to his cave hideout. There Robert Jordan meets some of Pablo's band, notably Maria; they're instantly interested in each other. He also meets Pilar, Pablo's imposing wife.A confrontation between Robert Jordan and Pablo ensues later that night, when Pablo announces that he won't let Robert Jordan blow up the bridge because he wants to play it safe. Unfortunately for Pablo, however, Pilar has other ideas, and when she declares that she's for the operation, everyone else falls in with her. Pablo's no longer in charge. Later that night, Robert Jordan, who's sleeping outside, is awakened by Maria. They sleep together.Day Two. Robert Jordan wakes to the sound of planes. Lots of fascist planes. It seems the fascists might be ready for the attack. Robert Jordan, Pilar, and Maria leave the camp to visit El Sordo, the leader of another band that's worked with Pablo's. On the way, Pilar tells the long and bloody tale of what happened in her town when the war began (one of the most famous parts of the book).They arrive at El Sordo's camp, and El Sordo agrees that his band will help in the attack, though he's not very happy about it. There's a hitch: to escape after the attack, everyone will need horses, and the two bands don't have enough horses for everyone. So El Sordo promises that he will steal some extra horses that evening. After leaving El Sordo's, Robert and Maria spend the afternoon having  earth-moving  sex and decide they're really in love with each other.It starts to snow as evening approaches. Back home at the cave, Pablo's apparently drunk. Another confrontation between Robert Jordan and Pablo ensues. It looks like there might be a showdown, but Pablo just retorts and leaves. Before too long he comes back and announces that his heart changed with the weather � he wants to help with the bridge now. Later in the night the snow stops, which is bad news: El Sordo's horse-thieves will leave snow tracks back to their hideout. Robert Jordan goes to sleep, and Maria joins.Day Three. Robert Jordan awakens to the sound of a mounted fascist patrol officer approaching. Though he hasn't even had a chance to get dressed, Robert Jordan shoots the intruder. Robert Jordan and several others set up a machine gun nearby and lie in wait for any patrol that might come too near the cave. A patrol does show up, but they have another destination: El Sordo's. El Sordo and his party are all killed.Later that night, after observing a lot of fascist movement in the area, it's clear to Robert Jordan the fascists are prepared for the Republican attack, and he decides to warn the Republican general. He sends Andr�s, a younger member of the band, with a dispatch to deliver across Republican lines.Robert Jordan is awakened at two in the morning by Pilar. Turns out Pablo's run off with the detonators for the explosives in a last ditch effort to sabotage the bridge attack. Without detonators, and without El Sordo, the mission now looks doomed. Still, Robert Jordan manages to have sex with Maria on last time. Then (still before sunrise), it's time to go.Surprise, surprise, Pablo returns. He's had a real change of heart this time, and he's brought a band of five men and their horses. Unfortunately, his climactic realization occurred after he'd thrown the detonators in the river, but the dynamite can also be triggered with grenades. The band all ride off to the bridge area, leaving their horses hidden in the woods nearby. They prepare for battle, but it's unclear whether the dispatch will reach the Republicans and the attack will be canceled.It does reach them, but too late: the attack isn't canceled. As Republican bombs begin to fall nearby, everyone moves into action. The sentry posts are taken and the bridge is blown, but several people are lost, and Pablo kills the men he brought to make sure there are enough horses for his own group.The depleted band flees on the horses, but as they escape amidst enemy fire, Robert Jordan's horse is toppled by a tank blast, and his leg is broken. Recognizing he would slow down his friends and compromise their escape, he makes them leave him, including Maria, who must be dragged away. Left alone to face death, in the hopes that he might buy his comrades more time, he lies in wait for the approaching fascists. There the book ends." ;

        StringTokenizer token  = new StringTokenizer(S);
        while(token.hasMoreTokens())
        {
            String currentWord = token.nextToken();
            tree.put(currentWord);
            SearchResult result = tree.get(currentWord);
            if (result != null)
            {
                System.out.printf("Word <%s> found %d times and is on level %d of the tree\n", currentWord, result.getCountOfWords(), result.getWordDepth());
            }
            else
            {
                //just for insurance
                System.out.printf("ERROR. Check your class for logic mistakes!!!");
            }
        }

    }
}
